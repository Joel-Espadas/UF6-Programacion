package com.example.database;

import com.example.database.models.Book;

import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            DatabaseManager dbManager = new DatabaseManager();

            Book book1 = new Book("Harry Potter I la Pedra Filosofal", "J.K. Rowling", 1997);
            Book book2 = new Book("El Resplandor", "Stephen King", 1977);
            dbManager.addBook(book1);
            dbManager.addBook(book2);

            List<Book> books = dbManager.getAllBooks();
            for (Book book : books) {
                System.out.println(book);
            }

            Book updatedBook = new Book(1, "EHarry Potter I la Pedra Filosofal", "J.K. Rowling", 1997);
            dbManager.updateBook(updatedBook);

            dbManager.deleteBook(2);

            books = dbManager.getAllBooks();
            for (Book book : books) {
                System.out.println(book);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
